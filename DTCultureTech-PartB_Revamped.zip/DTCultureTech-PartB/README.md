# DT CultureTech – Part B

This folder contains my Part-B submission for the DT Mission / PDGMS assignment.

## Files Included

- `partB_notes.md`  
  Detailed explanation of my understanding of the mission, the Question → Hypothesis → Experiment approach, AI usage, hallucination control, disagreement with AI, and final learning.

- `mindmap.png`  
  A detailed mindmap showing the DT thinking cycle.

- `hand_drawn_thought_process.png`  
  A detailed workflow sketch showing how I approached the assignment from reading it to final submission.

## What this submission focuses on

- structured thinking
- clear problem understanding
- hypothesis building
- research and verification
- responsible AI usage
- rejection of weak or unverifiable claims
- original thought process
- execution mindset

## How to use this folder

1. Read `partB_notes.md` first.
2. Open `mindmap.png` to see the mission logic visually.
3. Open `hand_drawn_thought_process.png` to understand the workflow I followed.

## Core message

AI helped me move faster, but the final thinking, verification, and decisions were done by me.