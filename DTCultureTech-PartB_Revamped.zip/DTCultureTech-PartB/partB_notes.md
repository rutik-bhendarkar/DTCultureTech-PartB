# DT Mission / PDGMS – Part B Notes

## 1. What I understood from the mission

My understanding of the DT Mission is that the company is not only checking whether I can write an answer. It is checking whether I can think in a structured way, verify information carefully, and explain my reasoning clearly.

The assignment is really testing:
- how I understand the problem,
- how I form an initial assumption,
- how I test that assumption,
- how I verify the evidence,
- and how I present the final result in a clean way.

This is why the mindmap and the hand-drawn workflow sketch are important. They show my process, not just the final answer.

## 2. What PDGMS means to me

I understood PDGMS as a workflow where:
- a question is identified clearly,
- a hypothesis is formed,
- evidence is collected,
- the evidence is tested,
- and the final execution is done carefully.

This is useful because in real work the first answer is not always the correct answer. A good analyst pauses, checks the evidence, and then decides what to trust.

## 3. Question → Hypothesis → Experiment

I used this cycle to structure my thinking.

### Question
What is the task asking?
What is the expected output?
What must be included?
What must not be missed?

### Hypothesis
What is my first assumption?
What direction seems reasonable?
What is the risk of being wrong?

### Experiment
Can I test the idea with evidence?
Can I compare sources?
Can I confirm whether the assumption is correct?

### Verification
Can I cross-check the result?
Can I reject weak claims?
Can I keep only verified data?

### Execution
Can I turn the verified result into a clean final file?
Can I organize the work properly?
Can I submit it in a way that is easy to review?

## 4. How I used AI

I used AI only as a support tool. It helped me with:
- structure,
- organizing ideas,
- drafting,
- and saving time.

But AI was not the final authority. I checked the output myself and rewrote parts that felt too generic or too confident without enough evidence.

## 5. How I controlled hallucination

My rule was simple:

**If I cannot verify it, I do not present it as a fact.**

To control hallucination, I:
- checked whether the claim made sense,
- verified it from a public source when possible,
- removed weak or uncertain claims,
- and kept assumptions separate from verified points.

This is important because AI can sound confident even when it is wrong.

## 6. Where I disagreed with AI

I did not accept AI output automatically. I disagreed when:
- the wording was too generic,
- the claim was not supported by evidence,
- or the conclusion sounded too certain.

In those cases I rewrote the part in a simpler, more practical style. That made the final work more human and more trustworthy.

## 7. Why the mindmap matters

The mindmap shows the structure of my thinking:
- question,
- hypothesis,
- experiment,
- verification,
- execution,
- and learning.

It proves that I did not jump directly to the final answer.

## 8. Why the handwritten sketch matters

The handwritten sketch shows the workflow in a more detailed and personal way. It shows:
- how I started,
- how I used AI,
- how I checked the output manually,
- how I rejected weak information,
- and how I finalized the submission.

That is important because it shows original thought, not just final text.

## 9. What I learned

The biggest lesson from this task is that good work is not only about speed. Good work is about:
- asking the right question,
- thinking step by step,
- checking evidence,
- rejecting weak information,
- and writing clearly.

AI can help with speed, but human judgment decides quality.

## 10. Final conclusion

This assignment helped me understand that structured thinking is very important. The best output is not the one that sounds the smartest. It is the one that is verified, organized, and honest.